package com.example.calculadoradivisa;

import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

public class MainActivity extends AppCompatActivity {

    // Dades de cada divisa, en el mateix ordre que els botons
    private final String[] codis = { "GBP", "USD", "JPY", "MXN" };
    private final String[] noms = { "LLIURES", "DÒLARS", "IENS", "PESOS" };
    private final int[] colors = { 0xFFA27BFF, 0xFF34C77B, 0xFFF0524F, 0xFFF4A6C6 };
    private final int[] colorsFoscos = { 0xFF1F1833, 0xFF12291C, 0xFF2E1517, 0xFF2C1A24 };

    private TextView tvEuros, tvResultat, tvRuta, tvDivisaNom, tvFactor, tvLogo;
    private MaterialCardView cardLogo;
    private MaterialButton btnCE, btnBorrar, btnIgual;
    private Button btnCanviarFactor;
    private MaterialButton[] botonsDivisa;

    private String entrada = "0";
    private int divisa = 1;
    private SharedPreferences factors;
    private DecimalFormat format;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        factors = getSharedPreferences("factors", MODE_PRIVATE);

        DecimalFormatSymbols simbols = new DecimalFormatSymbols();
        simbols.setDecimalSeparator(',');
        simbols.setGroupingSeparator('.');
        format = new DecimalFormat("#,##0.00", simbols);

        tvEuros = findViewById(R.id.tvEuros);
        tvResultat = findViewById(R.id.tvResultat);
        tvRuta = findViewById(R.id.tvRuta);
        tvDivisaNom = findViewById(R.id.tvDivisaNom);
        tvFactor = findViewById(R.id.tvFactor);
        tvLogo = findViewById(R.id.tvLogo);
        cardLogo = findViewById(R.id.cardLogo);
        btnCE = findViewById(R.id.btnCE);
        btnBorrar = findViewById(R.id.btnBorrar);
        btnIgual = findViewById(R.id.btnIgual);
        btnCanviarFactor = findViewById(R.id.btnCanviarFactor);
        Button btnComa = findViewById(R.id.btnComa);

        botonsDivisa = new MaterialButton[] {
                findViewById(R.id.btnLliures), findViewById(R.id.btnDollar),
                findViewById(R.id.btnYen), findViewById(R.id.btnPesos)
        };

        // Un listener per a cada botó
        int[] idsNumeros = { R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9 };
        for (int i = 0; i < idsNumeros.length; i++) {
            String numero = String.valueOf(i);
            findViewById(idsNumeros[i]).setOnClickListener(v -> afegirNumero(numero));
        }

        for (int i = 0; i < botonsDivisa.length; i++) {
            int index = i;
            botonsDivisa[i].setOnClickListener(v -> seleccionarDivisa(index));
        }

        btnComa.setOnClickListener(v -> {
            if (!entrada.contains(",")) {
                entrada += ",";
                actualitzar();
            }
        });

        btnBorrar.setOnClickListener(v -> {
            entrada = entrada.length() > 1 ? entrada.substring(0, entrada.length() - 1) : "0";
            actualitzar();
        });

        btnCE.setOnClickListener(v -> {
            entrada = "0";
            actualitzar();
        });

        btnIgual.setOnClickListener(v -> {
            if (factors.contains(codis[divisa])) {
                convertir();
            } else {
                demanarFactor();
            }
        });

        btnCanviarFactor.setOnClickListener(v -> demanarFactor());

        seleccionarDivisa(divisa);
    }

    private void afegirNumero(String numero) {
        int coma = entrada.indexOf(",");
        if (coma != -1 && entrada.length() - coma > 2) {
            Toast.makeText(this, R.string.max_decimals, Toast.LENGTH_SHORT).show();
            return;
        }
        if (entrada.equals("0")) {
            entrada = numero;
        } else if (entrada.length() < 12) {
            entrada += numero;
        }
        actualitzar();
    }

    private void actualitzar() {
        tvEuros.setText(entrada);
        tvResultat.setText("0,00");
    }

    private void convertir() {
        double euros = Double.parseDouble(entrada.replace(",", "."));
        double factor = factors.getFloat(codis[divisa], 0);
        tvResultat.setText(format.format(euros * factor));
    }

    // AlertDialog per demanar el factor; es guarda per a la propera vegada
    private void demanarFactor() {
        EditText etFactor = new EditText(this);
        etFactor.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(R.string.titol_factor)
                .setMessage(getString(R.string.missatge_factor, noms[divisa].toLowerCase()))
                .setView(etFactor)
                .setPositiveButton(R.string.desar, null)
                .setNegativeButton(R.string.cancelar, null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String text = etFactor.getText().toString().replace(".", ",");
            if (!text.matches("\\d+(,\\d+)?") || Double.parseDouble(text.replace(",", ".")) <= 0) {
                etFactor.setError(getString(R.string.error_factor));
                return;
            }
            factors.edit().putFloat(codis[divisa], Float.parseFloat(text.replace(",", "."))).apply();
            mostrarFactor();
            convertir();
            dialog.dismiss();
        }));

        dialog.show();
    }

    private void mostrarFactor() {
        if (factors.contains(codis[divisa])) {
            String factor = String.valueOf(factors.getFloat(codis[divisa], 0)).replace(".", ",");
            tvFactor.setText("1 € = " + factor + " " + codis[divisa]);
            btnCanviarFactor.setVisibility(View.VISIBLE);
        } else {
            tvFactor.setText(R.string.sense_factor);
            btnCanviarFactor.setVisibility(View.GONE);
        }
    }

    // Canvia la divisa i pinta la pantalla amb el seu color
    private void seleccionarDivisa(int index) {
        divisa = index;
        int color = colors[index];

        for (int i = 0; i < botonsDivisa.length; i++) {
            boolean seleccionat = i == index;
            botonsDivisa[i].setBackgroundTintList(ColorStateList.valueOf(seleccionat ? color : 0x00000000));
            botonsDivisa[i].setStrokeColor(ColorStateList.valueOf(seleccionat ? color : 0xFF2A3A55));
            botonsDivisa[i].setTextColor(seleccionat ? 0xFF0B1220 : 0xFFC3CDDD);
        }

        cardLogo.setCardBackgroundColor(color);
        tvLogo.setTextColor(0xFF0B1220);
        tvRuta.setText("EUR → " + codis[index]);
        tvDivisaNom.setText(noms[index]);
        tvResultat.setTextColor(color);
        btnCanviarFactor.setTextColor(color);

        btnIgual.setBackgroundTintList(ColorStateList.valueOf(color));
        btnCE.setBackgroundTintList(ColorStateList.valueOf(colorsFoscos[index]));
        btnCE.setTextColor(color);
        btnBorrar.setBackgroundTintList(ColorStateList.valueOf(colorsFoscos[index]));
        btnBorrar.setTextColor(color);

        mostrarFactor();
        actualitzar();
    }
}
